# main.py
import pathlib
import pandas as pd
import joblib
import os

from pipeline import (
    impute_missing,
    prepare_features,
    label_microtrend,
    prepare_1dcnn_df,
    train_wavecnn,
    prepare_gru_dataset,
    train_gru,
    prepare_timesnet_dataset,
    train_timesnet,
    prepare_tft_dataset,
    train_tft,
    print_dataset_overview,
    save_dataset_and_distribution,
    train_ppo,
    expand_dataset
)

os.chdir(os.path.dirname(__file__))
CACHE_DIR = pathlib.Path("cache")

CACHE_DIR = pathlib.Path(__file__).parent / "cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

CSV_PATH = pathlib.Path(__file__).parent.parent / "data" / "XRPUSDT_merge_180d.csv"


def main() -> None:
    print("[MAIN] Step 1: Loading raw data and imputing missing values...")
    df = pd.read_csv(CSV_PATH, parse_dates=["ts"], low_memory=False)
    print(f"[MAIN] Loaded data: {df.shape[0]} rows, {df.shape[1]} columns")

    df = impute_missing(df)
    print(f"[PREPROCESS] After imputation: {df.isna().sum().sum()} total missing values remain")

    df.to_csv(CACHE_DIR / "data.csv", index=False)
    print(f"[MAIN] Cached imputed data to {CACHE_DIR / 'data.csv'}")

    print_dataset_overview(df)

    # Prepare features and microtrend labels
    print("[MAIN] Step 2: Preparing features and microtrend labels...")
    dataset = prepare_features(df)
    print(f"[FEATURES] Features prepared: {dataset.shape[1]} features for {dataset.shape[0]} rows")

    dataset['microtrend_label'] = label_microtrend(
        dataset,
        price_col='ohlcv_5m_close',
        min_candles=3,
        profit_thr=0.02,
        stop_loss_thr=0.015
    )

    print(f"[MICROTREND] Assigned microtrend labels: {dataset['microtrend_label'].nunique()} unique labels")

    # Save outputs
    save_dataset_and_distribution(dataset)

    dataset = expand_dataset(dataset, n=6, noise_sigma=0.003)

    dataset.to_csv(f"{CACHE_DIR / 'dataset.csv'}", index=False)

    dist_aug = dataset['microtrend_label'].value_counts().sort_index()
    print(f"[EXPANDED DISTRIBUTION] {dist_aug.to_dict()}")
    # Wavelet + 1D-CNN
    print(f"[WAVECNN] Starting CNN dataset preparation")
    df_train_cnn, df_test_cnn, scaler_raw, scaler_wave = prepare_1dcnn_df(
        dataset,
        wavelet="db4",
        level=3,
        window_size=24,
        train_frac=0.8,
        raw_scaler_path=CACHE_DIR / "scaler_raw.pkl",
        wave_scaler_path=CACHE_DIR / "scaler_wave.pkl",
        dataset_train_path=CACHE_DIR / "wavecnn_dataset_train.pkl",
        dataset_test_path=CACHE_DIR / "wavecnn_dataset_test.pkl",
        class_freq_path=CACHE_DIR / "class_freqs.pt",
    )
    print(f"[WAVECNN] Prepared datasets: "
          f"{df_train_cnn.shape[0]} train samples, {df_test_cnn.shape[0]} test samples")
    print(f"[WAVECNN] Saved raw scaler → {CACHE_DIR / 'scaler_raw.pkl'}, "
          f"wavelet scaler → {CACHE_DIR / 'scaler_wave.pkl'}")
    print(f"[WAVECNN] Saved datasets → "
          f"{CACHE_DIR / 'wavecnn_dataset_train.pkl'} & {CACHE_DIR / 'wavecnn_dataset_test.pkl'}")
    print(f"[WAVECNN] Class frequencies written to → {CACHE_DIR / 'class_freqs.pt'}")
    print(f"[WAVECNN] START WAVECNN TRAINING")

    train_wavecnn(
        train_pkl=str(CACHE_DIR / "wavecnn_dataset_train.pkl"),
        test_pkl=str(CACHE_DIR / "wavecnn_dataset_test.pkl"),
        class_freqs_pt=str(CACHE_DIR / "class_freqs.pt"),
        model_out=str(CACHE_DIR / "wavecnn_model.pt"),
        emb_out=str(CACHE_DIR / "cnn_embeddings.parquet"),
        window=24,
        epochs=10,
        batch=256,
        lr=3e-4,
    )

    print(f"[WAVECNN] FINISH WAVECNN TRAINING")
    print("[GRU] Preparing GRU dataset")

    prepare_gru_dataset(
        events_pkl=CACHE_DIR / "imputed_events.pkl",
        emb_path=CACHE_DIR / "cnn_embeddings.parquet",
        seq_len=96,
        train_frac=0.8,
        scaler_path=CACHE_DIR / "scaler_gru.pkl",
        dataset_train_path=CACHE_DIR / "gru_dataset_train.pkl",
        dataset_test_path=CACHE_DIR / "gru_dataset_test.pkl"
    )

    print(f"[GRU] Saved GRU train/test datasets and scaler")

    print("[GRU] Training GRU model")
    train_gru(
        train_pkl=str(CACHE_DIR / "gru_dataset_train.pkl"),
        test_pkl=str(CACHE_DIR / "gru_dataset_test.pkl"),
        class_freqs_pt=str(CACHE_DIR / "class_freqs.pt"),
        events_pkl=str(CACHE_DIR / "imputed_events.pkl"),
        emb_path=str(CACHE_DIR / "cnn_embeddings.parquet"),
        model_out=str(CACHE_DIR / "gru_model.pt"),
        emb_out=str(CACHE_DIR / "gru_embeddings.parquet"),
        seq_len=96,
        epochs=10,
        batch_size=128,
        lr=3e-4,
        patience=3,
    )
    print("[GRU] Done")
    print("[TIMESNET] DATA PREP STARTED")

    prepare_timesnet_dataset(
        df=dataset,
        seq_len=288,
        horizon=288,
        train_dataset_path=CACHE_DIR / "timesnet_train.pt",
        test_dataset_path=CACHE_DIR / "timesnet_test.pt",
        scaler_path=CACHE_DIR / "timesnet_scaler.pkl",
    )
    print("[TIMESNET] DATA PREP COMPLETED")

    print("[TIMESNET] TRAINING STARTED")
    train_timesnet(
        train_pt=str(CACHE_DIR / "timesnet_train.pt"),
        test_pt=str(CACHE_DIR / "timesnet_test.pt"),
        events_pkl=str(CACHE_DIR / "imputed_events.pkl"),
        model_out=str(CACHE_DIR / "timesnet_model.pt"),
        embed_out=str(CACHE_DIR / "timesnet_embeddings.parquet"),
        forecast_out=str(CACHE_DIR / "timesnet_forecast.parquet"),
        seq_len=288,
        epochs=5,
        batch_size=256,
        lr=3e-4,
    )
    print(f"[TIMESNET] Training completed")

    print("[MAIN] All steps completed successfully.")

    print("[TFT] DATA PREP STARTED")
    full_dataset, feature_groups = prepare_tft_dataset(
        df_events=CACHE_DIR / "imputed_events.pkl",
        cnn_emb_path=CACHE_DIR / "cnn_embeddings.parquet",
        gru_emb_path=CACHE_DIR / "gru_embeddings.parquet",
        timesnet_emb_path=CACHE_DIR / "timesnet_embeddings.parquet",
        timesnet_pred_path=CACHE_DIR / "timesnet_forecast.parquet",
        seq_len=96,
        scaler_path=CACHE_DIR / "tft_scaler.pkl",
        dataset_path=CACHE_DIR / "tft_full_dataset.pt",
        train_size=0.8,
        train_features_path=CACHE_DIR / "tft_train_features.npy",
        train_targets_path=CACHE_DIR / "tft_train_targets.npy",
        test_features_path=CACHE_DIR / "tft_test_features.npy",
        test_targets_path=CACHE_DIR / "tft_test_targets.npy",
        strict=False,
    )
    joblib.dump(feature_groups, CACHE_DIR / "tft_feature_groups.pkl")
    print("[TFT] Saving scaler and datasets...")
    print("[TFT] DATA PREP COMPLETED\n")

    print("[MAIN] Training TFT model...")
    train_tft(
        train_features_path=CACHE_DIR / "tft_train_features.npy",
        train_targets_path=CACHE_DIR / "tft_train_targets.npy",
        test_features_path=CACHE_DIR / "tft_test_features.npy",
        test_targets_path=CACHE_DIR / "tft_test_targets.npy",
        feature_groups_pkl=CACHE_DIR / "tft_feature_groups.pkl",
        class_freqs_pt=CACHE_DIR / "class_freqs.pt",
        seq_len=96,
        model_out=CACHE_DIR / "tft_model.pt",
        emb_out=CACHE_DIR / "tft_embeddings.parquet",
        epochs=20,
        batch_size=128,
        lr=3e-4,
        step_size=5,
        gamma=0.5,
    )
    print("[MAIN] Training completed.")
    exit()

    # ------------------------------------------------------------------ #
    # 7. PPO + Kelly Criterion
    # ------------------------------------------------------------------ #
    acc, kelly = train_ppo(
        emb_path=CACHE_DIR / "tft_embeddings.parquet",
        csv_path=CSV_PATH,
        price_col="ohlcv_5m_close",
        model_out=CACHE_DIR / "ppo_trading.zip",
        total_timesteps=20000,
    )
    print(f"[MAIN] PPO direction-accuracy: {acc * 100:.2f}%")
    print(f"[MAIN] PPO Kelly fraction  : {kelly:.3f}")


if __name__ == "__main__":
    main()
