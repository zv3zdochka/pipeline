# pipeline/train_timesnet.py
import pathlib
import warnings
import joblib
import torch
import pandas as pd
import numpy as np
from sklearn.metrics import f1_score
from torch.utils.data import DataLoader
from torch import nn
import torch.nn.functional as F

from .prepare_dataset_TimesNet import TimesNetDataset
from .models.TimesNet import TimesNetModel

def focal_loss(
    logits: torch.Tensor,
    target: torch.Tensor,
    gamma: float = 2.0,
    alpha: list[float] | None = None,
) -> torch.Tensor:
    """
    Focal loss для многоклассовой задачи.
    alpha: список весов для классов [w_-1, w_0, w_+1].
    """
    ce = F.cross_entropy(logits, target, reduction="none")
    pt = torch.exp(-ce)
    if alpha is not None:
        a = torch.tensor(alpha, device=logits.device)[target]
    else:
        a = 1.0
    loss = a * (1 - pt).pow(gamma) * ce
    return loss.mean()


def _loader(ds, batch, shuffle):
    return DataLoader(
        ds,
        batch_size=batch,
        shuffle=shuffle,
        num_workers=4,
        pin_memory=True
    )


def train_timesnet(
    train_pt: str,
    test_pt: str | None = None,
    events_pkl: str | None = None,
    model_out: str = "timesnet_model.pt",
    embed_out: str = "timesnet_embeddings.parquet",
    forecast_out: str = "timesnet_forecast.parquet",
    seq_len: int = 288,
    epochs: int = 20,
    batch_size: int = 256,
    lr: float = 3e-4,
    device: str | None = None,
    patience: int = 6,
):
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")

    # --- Загрузка данных ---
    raw = torch.load(train_pt)
    X_train, y_train = raw["X"], raw["y"]
    if test_pt and pathlib.Path(test_pt).exists():
        raw_val = torch.load(test_pt)
        X_val, y_val = raw_val["X"], raw_val["y"]
    else:
        split = int(0.9 * len(X_train))
        X_train, X_val = X_train[:split], X_train[split:]
        y_train, y_val = y_train[:split], y_train[split:]

    # датасеты
    train_ds = TimesNetDataset(X_train, y_train, seq_len)
    val_ds   = TimesNetDataset(X_val,   y_val,   seq_len)

    train_loader = _loader(train_ds, batch_size, shuffle=True)
    val_loader   = _loader(val_ds,   batch_size, shuffle=False)

    # --- Считаем веса классов по y_train для focal_loss α ---
    counts = np.bincount(y_train + 1, minlength=3)  # классы [-1,0,1] → [c_-1,c_0,c_+1]
    alpha = (counts.max() / np.clip(counts, 1, None)).tolist()
    print(f"[TIMESNET] focal α → {alpha}")

    # --- Модель и оптимизатор ---
    model = TimesNetModel(
        seq_len=seq_len,
        n_features=X_train.shape[-1],
        d_model=128,
        n_blocks=4,
        num_classes=3,
    ).to(device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-2)
    # scheduler по метрике val_f1
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", patience=3, factor=0.5, verbose=True
    )

    best_f1 = 0.0
    no_improve = 0

    # --- Тренировка ---
    for ep in range(1, epochs + 1):
        model.train()
        running_loss = 0.0
        for xb, yb in train_loader:
            xb, yb = xb.to(device), (yb + 1).to(device)
            optimizer.zero_grad()
            logits, _ = model(xb)
            loss = focal_loss(logits, yb, gamma=2.0, alpha=alpha)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            running_loss += loss.item() * yb.size(0)

        # --- Валидация ---
        model.eval()
        all_preds, all_trues = [], []
        with torch.no_grad():
            for xb, yb in val_loader:
                xb, yb = xb.to(device), (yb + 1).to(device)
                logits, _ = model(xb)
                preds = logits.argmax(dim=1)
                all_preds.append(preds.cpu().numpy())
                all_trues.append(yb.cpu().numpy())

        all_preds = np.concatenate(all_preds)
        all_trues = np.concatenate(all_trues)
        val_f1 = f1_score(all_trues, all_preds, average="macro", zero_division=0)
        train_loss = running_loss / len(train_ds)

        print(
            f"[TIMESNET] ep {ep:02d}/{epochs} "
            f"train_loss={train_loss:.4f}  val_f1={val_f1:.3f}"
        )

        # LR-scheduler и early stopping по одной метрике (val_f1)
        scheduler.step(val_f1)

        if val_f1 > best_f1:
            best_f1 = val_f1
            no_improve = 0
            torch.save(model.state_dict(), model_out)
            print(f"  ↳ new best F1={best_f1:.3f} (model saved → {model_out})")
        else:
            no_improve += 1
            print(f"  ↳ no improve, patience {no_improve}/{patience}")
            if no_improve >= patience:
                print("[TIMESNET] Early stopping")
                break

    print(f"[TIMESNET] Training completed, best F1={best_f1:.3f}")

    # --- Генерация эмбеддингов и прогнозов ---
    model.load_state_dict(torch.load(model_out, map_location=device))
    model.eval()
    full_X = np.concatenate([X_train, X_val], axis=0)
    full_y = np.concatenate([y_train, y_val], axis=0)
    full_ds = TimesNetDataset(full_X, full_y, seq_len)
    loader = _loader(full_ds, batch_size, shuffle=False)

    embeds, logits = [], []
    with torch.no_grad():
        for xb, _ in loader:
            xb = xb.to(device)
            logit, emb = model(xb)
            embeds.append(emb.cpu())
            logits.append(logit.cpu())

    embeds = torch.cat(embeds).numpy()
    probs  = torch.softmax(torch.cat(logits), dim=1).numpy()[:, 2]

    if events_pkl and pathlib.Path(events_pkl).exists():
        ev = joblib.load(events_pkl).set_index("ts").sort_index()
        idx = ev.index[seq_len : seq_len + len(probs)]
    else:
        idx = pd.RangeIndex(len(probs))

    pd.DataFrame(embeds, index=idx).to_parquet(embed_out)
    pd.DataFrame({"timesnet_pred": probs}, index=idx).to_parquet(forecast_out)
    print(f"[TIMESNET] Embeddings  → {embed_out}")
    print(f"[TIMESNET] Forecasts   → {forecast_out}")
