import pandas as pd
import numpy as np
import random

# Read the original CSV
input_csv = 'D:\PyCharmProjects\TFT\src\cache\data.csv'  # замените на ваше имя файла

df = pd.read_csv(input_csv, parse_dates=['ts'])

def compute_trend(close_series, window=3, thr=1e-6):
    """
    Compute simple linear trend over a rolling window.
    Returns +1 for upward trend, -1 for downward, 0 for sideways.
    """
    trends = [0] * len(close_series)
    for i in range(len(close_series)):
        if i < window-1:
            trends[i] = 0
            continue
        y = close_series.values[i-window+1:i+1]
        x = np.arange(window)
        slope = np.polyfit(x, y, 1)[0]
        if slope > thr:
            trends[i] = 1
        elif slope < -thr:
            trends[i] = -1
        else:
            trends[i] = 0
    return pd.Series(trends, index=close_series.index)

# Compute trend based on 5m close
df['trend'] = compute_trend(df['ohlcv_5m_close'], window=3)

# Map actions to IDs
action_map = {
    'Short': 1,
    'Long': 2,
    'Exit short': 3,
    'Exit long': 4,
    'Hold': 5
}

actions = []
prev_trend = 0
for idx, row in df.iterrows():
    t = row['trend']
    if t == 1:
        # Trend rising -> Long
        action = 'Long' if prev_trend != 1 else 'Hold'
    elif t == -1:
        # Trend falling -> Short
        action = 'Short' if prev_trend != -1 else 'Hold'
    else:
        # Sideways -> exit if we were in trend
        if prev_trend == 1:
            action = 'Exit long'
        elif prev_trend == -1:
            action = 'Exit short'
        else:
            action = 'Hold'
    actions.append(action)
    prev_trend = t

# Generate confidence
confidences = []
for act in actions:
    if act == 'Hold':
        conf = random.uniform(0.3, 0.9)
    else:
        conf = random.random()
    confidences.append(conf)

# Build output DataFrame
out = pd.DataFrame({
    'ts': df['ts'].dt.strftime('%Y-%m-%d %H:%M:%S'),
    'action_id': [action_map[a] for a in actions],
    'action': actions,
    'confidence': confidences
})

# Save to CSV
out.to_csv('actions.csv', index=False)
print("Generated actions.csv with", len(out), "rows.")
