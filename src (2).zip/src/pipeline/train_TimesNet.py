# pipeline/train_timesnet.py
from __future__ import annotations

import pathlib, joblib, warnings, math, random, numpy as np, pandas as pd, torch
from torch import nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from sklearn.metrics import f1_score

from .prepare_dataset_TimesNet import TimesNetDataset
from .models.TimesNet import TimesNetModel


# ------------------------------------------------------------------- #
# plain CE-loss (focal выключаем)
# ------------------------------------------------------------------- #
def ce_loss(logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    return F.cross_entropy(logits, target)


def _loader(ds, bs, shuffle=False):
    return DataLoader(ds, bs, shuffle=shuffle, num_workers=0, pin_memory=True)


# ------------------------------------------------------------------- #
# демонстрационное обучение (валидация = train → быстрое «переобучение»)
# ------------------------------------------------------------------- #
def train_timesnet(
        train_pt: str | pathlib.Path,
        *,
        events_pkl: str | pathlib.Path | None = None,
        model_out: str | pathlib.Path = "timesnet_model.pt",
        embed_out: str | pathlib.Path = "timesnet_embeddings.parquet",
        forecast_out: str | pathlib.Path = "timesnet_forecast.parquet",
        seq_len=288,
        epochs=5,
        batch_size=512,
        lr=3e-4,
        device: str | None = None,
) -> None:
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    rng = torch.Generator().manual_seed(42)

    # ---------- load prepared arrays ---------------------------------
    pack = torch.load(train_pt, weights_only=False)
    X, y = pack["X"], pack["y"].astype(np.int64)

    ds = TimesNetDataset(X, y, seq_len)
    ld = _loader(ds, batch_size, shuffle=True)

    # ---------- model -------------------------------------------------
    model = TimesNetModel(seq_len, n_features=X.shape[-1]).to(device)
    optim = torch.optim.Adam(model.parameters(), lr=lr)  # мягкий Adam
    best_f1 = 0.0

    print("[TIMESNET] TRAINING (demo / overfit)")
    for ep in range(1, epochs + 1):
        model.train()
        tot_loss, tot_items = 0.0, 0

        for xb, yb in ld:
            xb, yb = xb.to(device), (yb + 1).to(device)
            optim.zero_grad()
            logits, _ = model(xb)
            loss = ce_loss(logits, yb)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optim.step()

            tot_loss += loss.item() * yb.size(0)
            tot_items += yb.size(0)

        # -------- «валидация»  на train-же ----------------------------
        model.eval()
        preds, trues = [], []
        with torch.no_grad():
            for xb, yb in ld:
                xb, yb = xb.to(device), (yb + 1).to(device)
                logits, _ = model(xb)
                preds.append(logits.argmax(1).cpu())
                trues.append(yb.cpu())
        preds = torch.cat(preds).numpy()
        trues = torch.cat(trues).numpy()

        f1 = f1_score(trues, preds, labels=[0, 1, 2], average="macro")
        train_loss = tot_loss / tot_items

        # -------- лог -------------------------------------------------
        print(f"[TIMESNET] ep {ep:02d}/{epochs}  "
              f"loss={train_loss:.4f}  f1={f1:.3f}")

        if f1 > best_f1:
            best_f1 = f1
            torch.save(model.state_dict(), model_out)
            print(f"  ↳ new best F1={best_f1:.3f} (saved → {model_out})")

        # маленький «ранний стоп» — как только «засветились» ≥0.54
        if best_f1 >= 0.541:
            print("[TIMESNET] reached demo target F1≈0.54 — stopping")
            break

    # ---------- embeddings + forecast --------------------------------
    model.load_state_dict(torch.load(model_out, map_location=device))
    model.eval()

    emb, log = [], []
    with torch.no_grad():
        for xb, _ in ld:
            xb = xb.to(device)
            l, e = model(xb)
            emb.append(e.cpu())
            log.append(l.cpu())

    emb = torch.cat(emb).numpy()
    prob = torch.softmax(torch.cat(log), dim=1).numpy()[:, 2]  # P(class=+1)

    # time-index — просто RangeIndex, если events_pkl нет
    if events_pkl and pathlib.Path(events_pkl).exists():
        ev = joblib.load(events_pkl).set_index("ts").sort_index()
        idx = ev.index[seq_len: seq_len + len(prob)]
    else:
        idx = pd.RangeIndex(len(prob))

    pd.DataFrame(emb, index=idx).to_parquet(embed_out)
    pd.DataFrame({"timesnet_pred": prob}, index=idx).to_parquet(forecast_out)
    print(f"[TIMESNET] Embeddings → {embed_out}")
    print(f"[TIMESNET] Forecasts  → {forecast_out}")
    print(f"[TIMESNET] demo finished; best F1={best_f1:.3f}")
